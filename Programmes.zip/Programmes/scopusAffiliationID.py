#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug  3 13:45:38 2023

@author: bafg9

Programme to extract affiliation IDs from Scopus
"""

import json
import requests
import re


infile = open('University names list.txt','r')
outfile = open('Scopus affiliation IDs.txt','w')
outfile.write('Short name\tAffiliation ID\tScopus name\tOther names\n')

infile.readline()

for line in infile:
    parts = line.split('\t')
    if len(parts)>1:
        shortName = parts[0].replace('_',' ')
        institution = parts[1].strip()
        print(institution)
        
        searchURL = f'https://api.elsevier.com/content/search/affiliation?query=affil({institution})&apiKey=c1aa029a14c379be80cd32504267c845'
        
        page = requests.get(searchURL).text
        pageJ = json.loads(page)
        
        if 'Result set was empty' not in page and 'service-error' not in pageJ:
                        
            match = False
            for i in range(5):
                if i < len(pageJ['search-results']['entry']):
                    affiliationName = pageJ['search-results']['entry'][i]['affiliation-name']
                    if shortName in affiliationName.lower():
                        match = True
                        affiliationID = pageJ['search-results']['entry'][i]['dc:identifier']
                        affiliationID = re.findall('\d+',affiliationID)[0]
                        break
            if match:
                outfile.write(parts[0]+'\t'+affiliationID+'\t'+affiliationName)
            else:
                print('Not found')
                outfile.write(parts[0]+'\t\t')
            for i in range(1,len(parts)):
                outfile.write('\t'+parts[i])
            
            
outfile.close()
infile.close()
