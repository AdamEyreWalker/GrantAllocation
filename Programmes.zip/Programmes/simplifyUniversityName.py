#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 15 13:49:45 2023

@author: bafg9

needs the file 'Scopus affiliation IDs - updated.txt' in the same directory
note it only knows about Scopus affliation IDs that are UK based institutions
"""

import re

scopusNametoID = {}
scopusIDtoName = {}

def loadScopusAffiliationIDs():
    global scopusIDs
    infile = open('Scopus affiliation IDs - updated.txt','r')   #the updated file has been manually curated
    infile.readline()
    for line in infile:
        parts = line.split('\t')
        if len(parts)>1:
            scopusNametoID[parts[0]] = parts[1]
            scopusIDtoName[parts[1]] = parts[0]
    infile.close()
    

def scopusAffiliationID(university):
    if len(scopusNametoID) == 0:
        loadScopusAffiliationIDs()        
    if university in scopusNametoID:
        return scopusNametoID[university]
    else:
        return 'unknown'

def scopusAffiliationName(ID):
    if len(scopusIDtoName) == 0:
        loadScopusAffiliationIDs()        
    if ID in scopusIDtoName:
        return scopusIDtoName[ID]
    else:
        return 'unknown'


def simplifyUniversityName(university):
    
    exclusions = ['ab_agri_ltd','agroscope','astraZeneca_plc','biocaldol_ltd',
                  'bioline_uk_limited','cab_international',
                  'defence_science_&_tech_lab_dstl','defence_science_and_technology_laboratory',
                  'deltadot_ltd','eagle_genomics_ltd','glaxosmithkline_plc',
                  'independent','independent_consultant','jncc','lisk_and_jones_consultants_ltd',
                  'pol','private_consultant','restoration_appearance_&_function_tst','rolls_royce',
                  'sahfos','shire_pharmaceuticals_dev_ltd','simcyp_limited','simcyp_ltd','tahir_independent',
                  'vernalis_research_ltd','wr_plc','sesvanderhave','procter_&_gamble_limited','rsk_adas_ltd',
                  'medicines_discovery_catapult','sal_scientific_ltd','pfizer','medimmune_ltd','private_address',
                  'fujifilm_diosynth_biotechnologies_uk_ltd','selcia_ltd','procter_and_gamble_uk','gsk_consumer_healthcare',
                  'pfizer_animal_health','genetix_ltd','molecular_devices_ltd','btr_change_&_technology_group',
                  'unilever_corporate_research','syngenta','pall','novartis','medimmune','medimmune_limited',
                  'pall_europe_ltd','diamond_light_source','rsk_adas_ltd','school_pharmacy','biocaldol_ltd','bioline_uk_limited',
                  'biotech_consultants_ltd','astrazeneca','astrazeneca_plc','btr_change_and_technology_group',
                  'defence_science_and_tech_lab_dstl','glaxosmithkline','medicines_discovery_catapault','cib-cisc','cib-csic','eagle_genomics',
                  'hydrology','restoration_appearance_and_function_tst','procter_and_gamble_limited','aviagen_ltd','national_trust','syngenta_ltd',
                  'limerick_institute_technology']
    university = university.lower()
    university = re.sub('university|University|of |the |The |for |\"|\,|\'|_','',university)
    university = re.sub('\s+',' ',university)
    university = re.sub('\(.+\)','',university)
    university = re.sub('\/.+','',university)
    university = university.replace('nerc','')
    university = university.replace('&','and')
    university = university.strip()
    if university in ['babraham institute (cambridge)','babraham institute bbsrc','barbraham insitute']:
        university = 'babraham institute'
    if 'imperial' in university:
        university = 'imperial college london'
    if 'moredun' in university:
        university = 'moredun research institute'
    if 'mrc' in university:
        university = 'mrc-laboratory'
    if 'agricultural botany' in university:
        university = 'national institute agricultural botany'
    if 'niab' in university:
        university = 'national institute agricultural botany'
    if 'malling' in university:
        university = 'national institute agricultural botany'
    if 'belfast' in university:
        university = 'queens belfast'
    if university in ['scotland rural college','scotlands rural college','sruc','sruc - scotlands rural college','sruc']:
        university = 'scotlands rural college'
    if 'stfc' in university:
        university = 'science and technology facilities council'
    if 'teagasc' in university:
        university = 'teagasc'
    if 'wellcome trust' in university:
        university = 'wellcome trust'
    if 'brunel' in university:
        university = 'brunel'
    if 'embl' in university:
        university = 'european molecular biology laboratory'
    if 'oceanograph' in university:
        university = 'national oceanography centre'
    if 'rurford' in university or 'rutherford' in university:
        university = 'rutherford appleton laboratory'
    if 'bedford' in university:
        university = 'bedfordshire'
    if 'heartfordshire' in university:
        university = 'hertfordshire'
    if 'heriot' in university:
        university = 'heriot-watt'
    if 'economics' in university and 'london' in university:
        university = 'london_school_economics'
    if 'rothamstead' in university:
        university = 'rothamsted_research'
    if 'holloway' in university:
        university = 'royal_holloway_london'
    if 'scottish' in university and 'universities' in university and 'env' in university:
        university = 'scottish_universities_environmental_research_centre'
    if 'suerc' in university:
        university = 'glasgow'
    if university == 'bas':
        university = 'british_antarctic_survey'
    if university == 'ibers':
        university = 'aberystwyth'
    if 'abertay' in university:
        university = 'abertay'
    if 'birkbeck' in university:
        university = 'birkbeck'
    if 'ecology' in university and 'hydrology' in university:
        university = 'centre for ecology and hydrology'
    if university == 'institute food research':
        university = 'quadram institute bioscience'
    if university == 'institute animal health':
        university = 'pirbright institute'
    if university == 'genome analysis centre':
        university = 'earlham institute'

    university = university.replace(' ','_')

    if university in exclusions:
        university = 'excluded'

    return university


