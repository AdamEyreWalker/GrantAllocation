#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 28 14:51:45 2023

@author: bafg9
"""

import requests
import os
import json
import re
import glob
# import sys
# import certifi
import simplifyUniversityName as sun


def getScopusData(lastName,initial,university):

    folderName = council+' scopus downloads/'+lastName+'_'+initial+'_'+university
    
    
    if not os.path.exists(folderName):
        os.mkdir(folderName)
        
    if os.listdir(folderName) == []:    
        
        print(lastName+'_'+initial+'_'+university)
            
        searchURL = f'https://api.elsevier.com/content/search/scopus?query=author-name({lastName},%20{initial})%20and%20affil({university})&view=complete&count=25&cursor=*&apiKey=c1aa029a14c379be80cd32504267c845'
        page = requests.get(searchURL).text
        pageJ = json.loads(page)
        
        if 'Result set was empty' not in page and 'service-error' not in pageJ: #we have some results. service-errors can be caused by unexpected characters in the name, such as accented characters
        
            i = 0
            try:
                while 'entry' in pageJ['search-results']:
                    
                    outfile = open(folderName+'/'+lastName+'_'+initial+'_'+university+'_'+str(i)+'.txt','w')
                    i += 1
                    outfile.write(page)
                    outfile.close()
                    if len(pageJ['search-results']['link']) > 2:     #there is more than one page of results
                        searchURL = pageJ['search-results']['link'][2]['@href']
                        page = requests.get(searchURL).text
                        pageJ = json.loads(page)
                    else:
                        break
            except:
                x = 0
 

council = 'NERC'
# council = 'BBSRC'

# os.environ['REQUESTS_CA_BUNDLE'] = os.path.join(os.path.dirname(sys.argv[0]), certifi.where())

filenames = glob.glob('Cleaned data/'+council+' Panel Data/*.txt')

uniqueNames = []

for filename in filenames:
    print(filename)
    infile = open(filename,'r',encoding='latin1')
    infile.readline()
    
    for line in infile:
        line = line.strip()
        if line != '':
            line = line.replace('_','')
            parts = line.split('\t')
            try:
                surname = parts[1].strip().lower()
                initial = parts[2].strip()[0].lower()
                university = sun.simplifyUniversityName(parts[3].strip())           
                index = surname+'\t'+initial+'\t'+university
                if index not in uniqueNames:
                    uniqueNames.append(index)
                    getScopusData(surname,initial,university)
            except:
                print('Problem line : ',line)
    infile.close()
