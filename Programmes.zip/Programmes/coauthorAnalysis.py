""" 
Program to calculate the rate at which co-authors of panel mwembers receive grants when the panel member is on the pabel in question, or when they are not on the panel (but serve at some other time)

This version is based on the original collaboratorAnalysis.py programme. This seems rather simpler than my recent version

The programme reads all the panel files for the years being considered. Then it raeds the panel and grant data for a particular round in a year.
It compiles the co-author data for panel

"""

import re
import glob
import random
import json
import simplifyUniversityName as sun



def getPublicationYears():
    global council, publicationYears
    
    publicationYears = {}
    infile = open('yearsOfPublication_'+council+'.txt','r')
    for line in infile:
        parts = line.split('\t')
        publicationYears[parts[0].lower()] = [int(parts[1]),int(parts[2])]
    infile.close()

    

def getAllPanelMemebers():
    
    global allPanelMembers
    
    filenames = glob.glob('Cleaned data/'+council+' Panel Data/'+phase+'*.txt')
    for filename in filenames:
      print(filename)
      infile = open(filename,'r',encoding='latin8')
      infile.readline()
      for line in infile:
          line = line.strip()
          if line != '':
              parts = line.split('\t')
              panel = parts[0].upper()
              lastName = parts[1].lower().strip()
              lastName = lastName.replace('_','')
              initial = parts[2].strip()
              initial = initial[0].lower()
              university = sun.simplifyUniversityName(parts[3])
              nameCode = panel+'_'+lastName+'_'+initial+'_'+university
              nameCode = nameCode.lower()
              if nameCode not in allPanelMembers:
                  allPanelMembers[nameCode] = [[0,0.0],[0,0.0]]
    infile.close()
    
        
    

def processPanel(filename):
    
    global panelData
    
    file = open(filename,'r',encoding='latin8')
    file.readline()
    for line in file:
        line = line.strip()
        if line != '':
            parts = line.split('\t')
            panel = parts[0].upper()
            lastName = parts[1].lower().strip()
            lastName = lastName.replace('_','')
            initial = parts[2].strip()
            initial = initial[0].lower()
            university = sun.simplifyUniversityName(parts[3])
            nameCode = panel+'_'+lastName+'_'+initial+'_'+university
            nameCode = nameCode.lower()
            if nameCode not in panelData:
                panelData.append(nameCode)
    file.close()
            
    
    
def processGrant(filename):
    
    global grantData
    
    file = open(filename,'r',encoding='latin8')
    file.readline()
    for line in file:
        line = line.strip()
        if line != '':
            parts = line.split('\t')
            panel = parts[0]
            panel = panel.replace('"','').strip()
            panel = panel[0]
            name = parts[2].strip().lower()
            name = name.replace('"','')
            name = re.sub('prof |professor |dr |doctor ','',name)
            if council == 'BBSRC':
                lastName = name.split(',')[0]
                initial = name.split(',')[1]
            else:
                lastName = name.split(' ')[-1]
                initial = name.split(' ')[0]
            initial = initial.strip()[0]
            university = sun.simplifyUniversityName(parts[3])
            nameCode = panel+'_'+lastName+'_'+initial+'_'+university
            nameCode = nameCode.lower()
            grantData.append(nameCode)
    file.close()

          

# Main program
council = 'NERC'
#council = 'BBSRC'

if council == 'NERC':
    phase = 'Phase III/'
else:
    phase = ''

startYear = 2010  #the analysis can be restricted by year, but this is currently set to use all data available
endYear = 2021

lowOffset = -5   #number of years before year being considered to consider coauthorship - i.e. -5 means consider coauthorship in the previous 5 years
highOffset = 0

infile = open('coauthorsJSON_'+council+'.txt','r')
coauthorData = json.loads(infile.read())
infile.close()

getPublicationYears()

allPanelMembers = {}
getAllPanelMemebers()

overallResults = {}

filenames = glob.glob('Cleaned data/'+council+' Panel Data/'+phase+'*.txt')

for filename in filenames:
    print(filename)
    panelData = []
    processPanel(filename)
    year = int(re.findall('\d+',filename)[0])
    if year >= startYear and year <= endYear:    #restrict the analysis to a subset of years - useful if the panel structure, or the topics considered have changed
        rm = re.findall('rm\d',filename)[0]
        grantFilename = 'Cleaned data/'+council+' Grant Data/' + phase + str(year) + '-awarded-grants-' + rm + '.txt'
        grantData = []
        processGrant(grantFilename)
        
        
        for panelMember in allPanelMembers:
            coauthorList = []
            name = panelMember[2:]     #get rid of the panel name (e.g. A) and the underscore leaving lastname_initial_university
            panel = panelMember[0]
            if name in coauthorData:   #for this lastname_initial_university compile a list of co-authors over the required range of years
                for yr in range(year+lowOffset,year+highOffset+1):
                    if str(yr) in coauthorData[name]:
                        for coauthor in coauthorData[name][str(yr)]:
                            coauthor = coauthor.lower()
                            coauthorPanel = panel+'_'+coauthor
                            if coauthor != name: #and coauthorPanel not in coauthorList:            #check that the coauthor is not the panel member themselves
                                coauthorList.append(coauthorPanel)    #.replace('_','\t'))
                
                if len(coauthorList) > 0:
                    matches = set(coauthorList) & set(grantData)
                    noOfMatches = len(matches)                               
                    
                    if year >= publicationYears[name][0] and year <= publicationYears[name][1]:    #check the panel member was still at this university
                        if panelMember in panelData:                   #this panel member sat on this instance of the panel
                            allPanelMembers[panelMember][0][0] += 1    #tally number of panels this panel member sat on
                            allPanelMembers[panelMember][0][1] += noOfMatches   #tally number of grants funded to collaborator of panel member when on panel
                        else:
                            allPanelMembers[panelMember][1][0] += 1             #tally number of panels this panel member did NOT sit on
                            allPanelMembers[panelMember][1][1] += noOfMatches   #tally number of grants funded to collaborator of panel member when NOT on panel
         
        
outfile = open(council+' coauthor analysis - ' +phase[:-1]+'.txt','w')

outfile.write('Panel_Last name_First name_University\tTimes on panel\tGrants to coauthor when on panel\tMean grants on panel\tTimes not on panel\tGrants to coauthor when not on panel\tMean grants not on panel\n')



for panelMember in allPanelMembers:
    if allPanelMembers[panelMember][0][0]>0 and allPanelMembers[panelMember][1][0]>0 and (allPanelMembers[panelMember][0][1]+allPanelMembers[panelMember][1][1])>0:
        outfile.write(panelMember)
        for x in range(2):
            for y in range(2):
                outfile.write('\t'+str(allPanelMembers[panelMember][x][y]))
            outfile.write('\t'+str(allPanelMembers[panelMember][x][1]/allPanelMembers[panelMember][x][0]))
        outfile.write('\n')

outfile.close()
    

