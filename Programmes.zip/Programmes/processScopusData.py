#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 13 13:39:34 2023

@author: bafg9

Programme to process the Scopus publication data. It produces two files; one which lists the first and last year which an indidual published papers at an institution, 
and one listing all the coauthors for each of the years that the academic publishes in


"""

import simplifyUniversityName as sun
import glob
import re
import json

council = 'NERC'
#council = 'BBSRC'


yearsOfPublication = {}    #dictionary which keeps track of which year the author has published in
coauthors = {}             #dictionary to keep the co-author data. each panel member has an entry and within that each year they published has an entry; for each year there is a list of all co-authors as lastName_initial_university

folders = glob.glob('Scopus downloads - '+council+'/*/')
#folders = folders[:3]

for folder in folders:
    parts = folder.split('/')
    personUniversity = parts[-2]
    if personUniversity not in yearsOfPublication:
        yearsOfPublication[personUniversity] = []
    if personUniversity not in coauthors:
        coauthors[personUniversity] = {}
    
    university = parts[-2]
    university = re.sub('^.*?_','',university)    #remove the last name
    university = re.sub('^.*?_','',university)    #remove the initial
    
    affiliationID = sun.scopusAffiliationID(university)    #get the affiliation ID of the person whose record we are considering
    
    subParts = parts[-2].split('_')
    lastName = subParts[0]
    initial = subParts[1]
    
    if affiliationID != 'unkown':    #an affiliation ID was returned
    
        print(personUniversity)
        fileNames = glob.glob(folder+'*.txt')
            
        for fileName in fileNames:
            infile = open(fileName,'r')
            page = infile.read()
    
            pageJ = json.loads(page)
            
            for paper in pageJ['search-results']['entry']:       #step through each of the papers

                correctAuthor = False                            #we now have to check that this is the author we are interested in. A search for Smith_L at Cambridge returns all papers written by Smith_L at Cambridge or with a coauthor at Cambridge
                if 'author' in paper:
                    for author in paper['author']:
                        if 'surname' in author and 'initials' in author and 'afid' in author and author['surname'] is not None and author['initials'] is not None and author['afid'] is not None:
                            authorLastName = author['surname'].lower().strip()
                            authorInitial = author['initials'][0].lower().strip()
                            authorAffiliationID = author['afid'][0]['$']
                            if authorLastName == lastName and  authorInitial == initial and authorAffiliationID == affiliationID:
                                correctAuthor = True
                                break
                    
                    if correctAuthor:
                        year = int(paper['prism:coverDate'][:4])
                        if year not in yearsOfPublication[personUniversity]:
                            yearsOfPublication[personUniversity].append(year)       #keep track of which years the panel member has published in
                        
                        if year not in coauthors[personUniversity]:
                            coauthors[personUniversity][year] = []
                        if len(paper['author']) < 20:                   #exclude papers with many authors
                            for author in paper['author']:
                                if 'surname' in author and 'initials' in author and 'afid' in author and author['surname'] is not None and author['initials'] is not None and author['afid'] is not None:
                                    university = sun.scopusAffiliationName(author['afid'][0]['$'])
                                    name = author['surname'].lower()+'_'+author['initials'][0].lower()+'_'+university
                                    coauthors[personUniversity][year].append(name)
            infile.close()

outfile = open('coauthorsJSON_'+council+'.txt','w')

outfile.write(json.dumps(coauthors))

outfile.close()

outfile = open('yearsOfPublication_'+council+'.txt','w')

for personUniversity in yearsOfPublication:
    years = yearsOfPublication[personUniversity]
    if years != []:   
        years.sort()
        outfile.write(personUniversity+'\t'+str(years[0])+'\t'+str(years[-1])+'\n')
    
outfile.close()
