#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 13 12:08:40 2023

@author: bafg9

A programme to find all the university names in the analysis
"""

import glob
import simplifyUniversityName as sun

councils = ['NERC','BBSRC']
dataTypes = ['Panel','Grant']

uniqueNames = {}

for council in councils:
    for dataType in dataTypes:

        filenames = glob.glob('Cleaned data/'+council+' '+dataType+' Data/*.txt')
         
        for filename in filenames:
            print(filename)
            infile = open(filename,'r',encoding='latin1')
            infile.readline()
            
            for line in infile:
                line = line.strip()
                if line != '':
                    line = line.replace('_','')
                    parts = line.split('\t')
                    try:
                        universityName = parts[3].strip()
                    except:
                        x = 0
                    simpleName = sun.simplifyUniversityName(universityName)           
                    if simpleName not in uniqueNames:
                        uniqueNames[simpleName] = ''
                    if universityName not in uniqueNames[simpleName]:
                        uniqueNames[simpleName] += '\t'+universityName
            infile.close()

outfile = open('University names list.txt','w')

outfile.write('Simple name\tUniversity name\n')  

for name in uniqueNames:
    outfile.write(name+uniqueNames[name]+'\n')

outfile.close()